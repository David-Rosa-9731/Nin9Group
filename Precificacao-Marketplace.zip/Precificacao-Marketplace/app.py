import streamlit as st
import pandas as pd
from data import load_data
from utils import calculate_margin, format_currency, validate_input

def main():
    st.title("Calculadora de Margem de Contribuição - Marketplaces")

    # Reload data to ensure we have the latest configuration
    COMPANIES, MARKETPLACE_FEES = load_data()

    # Marketplace selection
    marketplace = st.selectbox(
        "Selecione o Marketplace",
        options=list(MARKETPLACE_FEES.keys())
    )

    # Company selection
    company = st.selectbox(
        "Selecione o CNPJ",
        options=list(COMPANIES.keys())
    )

    # Input values
    col1, col2 = st.columns(2)

    with col1:
        selling_price_input = st.text_input(
            "Preço de Venda (R$)",
            value="0,00"
        )
        is_valid_price, selling_price = validate_input(selling_price_input)

        if not is_valid_price:
            st.error("Por favor, insira um valor válido para o preço de venda")

        product_cost_input = st.text_input(
            "Custo do Produto (R$)",
            value="0,00"
        )
        is_valid_cost, product_cost = validate_input(product_cost_input)

        if not is_valid_cost:
            st.error("Por favor, insira um valor válido para o custo do produto")

        shipping_cost_input = st.text_input(
            "Custo do Frete (R$)",
            value="0,00"
        )
        is_valid_shipping, shipping_cost = validate_input(shipping_cost_input)

        if not is_valid_shipping:
            st.error("Por favor, insira um valor válido para o custo do frete")

        reduced_rate_input = st.text_input(
            "Taxa Reduzida (R$)",
            value="0,00"
        )
        is_valid_reduced_rate, reduced_rate = validate_input(reduced_rate_input)

        if not is_valid_reduced_rate:
            st.error("Por favor, insira um valor válido para a taxa reduzida")

    # Calculate results
    if is_valid_price and is_valid_cost and is_valid_shipping and is_valid_reduced_rate:
        results = calculate_margin(
            selling_price=selling_price,
            product_cost=product_cost,
            shipping_cost=shipping_cost,
            marketplace_fee=MARKETPLACE_FEES[marketplace],
            company_tax=COMPANIES[company].tax_rate,
            marketplace_name=marketplace,
            reduced_rate=reduced_rate
        )

        # Display results
        st.header("Resultados")

        col1, col2 = st.columns(2)

        with col1:
            st.metric(
                "Margem de Contribuição",
                format_currency(results["margin"]),
                f"{results['margin_percentage']:.2f}%"
            )

            st.metric(
                "Comissão do Marketplace",
                format_currency(results["marketplace_fee"]),
                f"{MARKETPLACE_FEES[marketplace]['commission_rate']}%"
            )

            if results["fixed_fee"] > 0:
                st.metric(
                    "Tarifa Fixa do Marketplace",
                    format_currency(results["fixed_fee"]),
                    ""
                )

        with col2:
            st.metric(
                "Taxa de Imposto",
                format_currency(results["company_tax"]),
                f"{COMPANIES[company].tax_rate}%"
            )

            st.metric(
                "Custo do Frete",
                format_currency(shipping_cost),
                ""
            )

            if reduced_rate > 0:
                st.metric(
                    "Taxa Reduzida",
                    format_currency(reduced_rate),
                    ""
                )

        # Detailed breakdown
        st.subheader("Detalhamento")

        breakdown_items = [
            'Preço de Venda',
            'Custo do Produto',
            'Custo do Frete',
            'Comissão do Marketplace',
            'Tarifa Fixa do Marketplace',
            'Taxa Reduzida',
            'Impostos',
            'Custos Totais',
            'Margem de Contribuição'
        ]

        breakdown_values = [
            format_currency(selling_price),
            format_currency(product_cost),
            format_currency(shipping_cost),
            format_currency(results["marketplace_fee"]),
            format_currency(results["fixed_fee"]),
            format_currency(reduced_rate),
            format_currency(results["company_tax"]),
            format_currency(results["total_costs"]),
            format_currency(results["margin"])
        ]

        df = pd.DataFrame({
            'Item': breakdown_items,
            'Valor': breakdown_values
        })

        st.table(df)

if __name__ == "__main__":
    main()