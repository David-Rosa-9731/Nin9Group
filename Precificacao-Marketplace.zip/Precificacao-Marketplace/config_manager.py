import json
import os
from typing import Dict, Any

CONFIG_FILE = "config.json"

def load_config() -> Dict[str, Any]:
    """Load configuration from JSON file."""
    if not os.path.exists(CONFIG_FILE):
        # Default configuration
        default_config = {
            "companies": {
                "RosaPink": {"name": "RosaPink", "tax_rate": 9.00},
                "Flash": {"name": "Flash", "tax_rate": 8.00},
                "Tejotta": {"name": "Tejotta", "tax_rate": 8.49},
                "Amora": {"name": "Amora", "tax_rate": 0.00},
                "Build": {"name": "Build", "tax_rate": 0.00}
            },
            "marketplace_fees": {
                "Mercado Livre": {
                    "commission_rate": 16.0,
                    "fixed_fee": "dynamic",  # Valor dinâmico baseado no preço
                },
                "Shopee": {
                    "commission_rate": 12.0,
                    "fixed_fee": 4.0,  # Tarifa fixa em reais
                },
                "Amazon": {
                    "commission_rate": 15.0,
                    "fixed_fee": 0.0,  # Por enquanto sem tarifa fixa
                }
            }
        }
        save_config(default_config)
        return default_config

    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_config(config: Dict[str, Any]) -> None:
    """Save configuration to JSON file."""
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4, ensure_ascii=False)