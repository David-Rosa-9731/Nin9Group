from dataclasses import dataclass
from typing import Dict
from config_manager import load_config

@dataclass
class Company:
    name: str
    tax_rate: float

def load_data():
    config = load_config()

    companies = {
        name: Company(data["name"], data["tax_rate"])
        for name, data in config["companies"].items()
    }

    marketplace_fees = config["marketplace_fees"]

    return companies, marketplace_fees

# Reload data to ensure we have the latest configuration
COMPANIES, MARKETPLACE_FEES = load_data()