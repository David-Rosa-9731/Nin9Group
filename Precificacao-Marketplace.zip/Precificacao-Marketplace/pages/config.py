import streamlit as st
from config_manager import load_config, save_config

def main():
    st.title("Configurações")

    # Load current config
    config = load_config()

    st.header("Configuração de CNPJs")
    st.caption("Ajuste as taxas de imposto para cada CNPJ")

    # Company settings
    companies = config["companies"]
    modified_companies = companies.copy()

    for company_name, company_data in companies.items():
        st.subheader(company_name)
        new_tax_rate = st.number_input(
            f"Taxa de imposto para {company_name} (%)",
            min_value=0.0,
            max_value=100.0,
            value=float(company_data["tax_rate"]),
            step=0.01,
            key=f"company_{company_name}"
        )
        modified_companies[company_name]["tax_rate"] = new_tax_rate

    st.header("Configuração de Marketplaces")
    st.caption("Ajuste as taxas e tarifas para cada marketplace")

    # Marketplace settings
    marketplaces = config["marketplace_fees"]
    modified_marketplaces = marketplaces.copy()

    for marketplace_name, marketplace_data in marketplaces.items():
        st.subheader(marketplace_name)
        commission_rate = st.number_input(
            f"Taxa/Comissão para {marketplace_name} (%)",
            min_value=0.0,
            max_value=100.0,
            value=float(marketplace_data.get("commission_rate", 0.0)), #Handle missing commission_rate
            step=0.01,
            key=f"marketplace_commission_{marketplace_name}"
        )

        if marketplace_name == "Mercado Livre":
            st.info("""
            A tarifa fixa do Mercado Livre é calculada automaticamente:
            - R$ 6,25 para produtos até R$ 29
            - R$ 6,50 para produtos entre R$ 29 e R$ 50
            - R$ 6,75 para produtos entre R$ 50 e R$ 79
            - Sem tarifa fixa para produtos acima de R$ 79
            """)
            fixed_fee = "dynamic"
        else:
            fixed_fee_input = st.text_input(
                f"Tarifa Fixa para {marketplace_name} (R$)",
                value=f"{marketplace_data.get('fixed_fee', 0.0):.2f}".replace(".", ","), #Handle missing fixed_fee
                key=f"marketplace_fee_{marketplace_name}"
            )
            try:
                fixed_fee = float(fixed_fee_input.replace("R$", "").replace(".", "").replace(",", ".").strip())
            except ValueError:
                st.error(f"Valor inválido para a tarifa de {marketplace_name}")
                fixed_fee = 0.0

        modified_marketplaces[marketplace_name] = {
            "commission_rate": commission_rate,
            "fixed_fee": fixed_fee
        }

    # Save button
    if st.button("Salvar Alterações"):
        new_config = {
            "companies": modified_companies,
            "marketplace_fees": modified_marketplaces
        }
        save_config(new_config)
        st.success("Configurações salvas com sucesso!")
        st.rerun()

if __name__ == "__main__":
    main()