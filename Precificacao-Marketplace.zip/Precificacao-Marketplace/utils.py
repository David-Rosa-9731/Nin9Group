from typing import Dict, Tuple

def format_currency(value: float) -> str:
    """Format value as Brazilian currency."""
    return f"R$ {value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def get_mercadolivre_fixed_fee(price: float) -> float:
    """Calculate Mercado Livre fixed fee based on product price."""
    if price < 29:
        return 6.25
    elif price < 50:
        return 6.50
    elif price < 79:
        return 6.75
    return 0.0

def calculate_margin(
    selling_price: float,
    product_cost: float,
    shipping_cost: float,
    marketplace_fee: Dict[str, float],
    company_tax: float,
    marketplace_name: str,
    reduced_rate: float = 0.0
) -> Dict[str, float]:
    """Calculate contribution margin and related values."""

    # Calculate marketplace fees
    commission_rate = marketplace_fee["commission_rate"]
    commission_value = (selling_price * commission_rate / 100)

    # Calculate fixed fee
    if marketplace_name == "Mercado Livre":
        fixed_fee = get_mercadolivre_fixed_fee(selling_price)
    else:
        fixed_fee = marketplace_fee["fixed_fee"]

    # Calculate tax
    company_tax_value = (selling_price * company_tax / 100)  # Imposto como porcentagem

    # Calculate total costs
    total_costs = (
        product_cost +
        shipping_cost +
        commission_value +
        fixed_fee +
        company_tax_value -
        reduced_rate  # Taxa Reduzida reduz os custos totais
    )

    # Calculate margin
    margin = selling_price - total_costs
    margin_percentage = (margin / selling_price) * 100 if selling_price > 0 else 0

    return {
        "margin": margin,
        "margin_percentage": margin_percentage,
        "marketplace_fee": commission_value,
        "fixed_fee": fixed_fee,
        "company_tax": company_tax_value,
        "total_costs": total_costs
    }

def validate_input(value: str) -> Tuple[bool, float]:
    """Validate and convert input to float."""
    try:
        # Remove currency symbol and convert Brazilian number format to float
        cleaned = value.replace("R$", "").replace(".", "").replace(",", ".").strip()
        if not cleaned:
            return False, 0.0
        value = float(cleaned)
        if value < 0:
            return False, 0.0
        return True, value
    except (ValueError, AttributeError):
        return False, 0.0